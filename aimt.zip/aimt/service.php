<!DOCTYPE html>
<html>
<head>
	<title>service</title>
	<style type="text/css">
    
    *{
    font-family: poppins;
    box-sizing: border-box;
    text-decoration: none;
}

body{
    margin: 0%;
}


section.section-1,section.section-2{
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    background-color: black;
}
.logo img{
    width: 120px;
    height: 70px;
}

div.block-1{
    display: flex;
    align-items: center;
}

div.block-1 div:first-child{
    margin-right: 40px;
}

div.phone-apointment{
    display: flex;
    align-items: center;
}

div.social-btn ul li i{
    font-size: 22px;
    margin: 10px 7px;
    color: dimgray;
}

div.social-btn ul li i:hover{
    color: steelblue;
}

ul{
    list-style: none;
    padding: 0;
    margin: 0;
    cursor: default;
}

li{
    display: inline-block;
}

div.phone-number{
    font-size: 18px;
    padding: 5px 10px;
    border: 1px solid red;
    border-radius: 20px;
    background-color: white;
}

div.phone-number i{
    transform: rotateY(180deg);
}

div.appointment button{
    border: none;
    background-color: #211163;
    font-size: 18px;
    color: white;
    padding: 10px 12px;
    border-radius: 30px;
    outline: none;
    margin: 0px 15px;
    transition: box-shadow 0.5s;
}

div.appointment button:hover{
    box-shadow: 0px 0px 15px white;
}

nav{
    background-color: #211163;
}

nav ul{
    text-align: center;
}

nav li{
    text-align: center;
}

nav ul li a{
    font-size: 18px;
    display: block;
    color: white;
    padding: 8px 10px;
    margin: 0px 5px;
    font-weight: 500;
    border-top: 4px solid transparent;    
    border-bottom: 4px solid transparent;
    border-radius: 2px;
    transition-property: border-bottom,background-color;
    transition-duration: 0.4s;
}

nav ul li a:hover{
    background-color: black;
    border-bottom: 4px solid white;
}
#toggle{
    display: none;
}

#toggle-btn{
    display: none;
    text-align: right;
}

#toggle-btn i{
    font-size: 25px;
    padding: 7px;
    background-color: white;
    margin: 10px;
    border-radius: 5px;
    cursor: pointer;
}
.service{
width: 1350px;
height: 500px;
background-color: white;
box-shadow: 0px 0px 10px #adb9cc;	
}
.service img{
width: 1350px;
height: 500px;

}

.service h2{
	font-size: 50px;
	margin: -330px 0px 0px 310px;
	color: white;
}
.service p{
	font-size: 21px;
	margin: 0px 0px 0px 430px;
	color: white;
}

.course{
	width: 1350px;
	height: 530px;
	background-color: none;
}
.course div{
	float: left;
	width: 240px;
	height: 230px;
	margin:30px 0px 0px 75px;
	background-color: none;
	box-shadow: 0px 0px 10px grey;
}
.course div:hover{
    box-shadow: 0px 0px 25px grey;

}
.course div img{
	width: 100px;
	height: 100px;
	text-align: center;
	align-items: center;
	margin: 5px 0px 0px 60px;
}
.course div h2{

font-size: 20px;
text-align: center;
}
.course div p{
    text-align: center;

}
.footer{
    width: 1360px;
    height: 330px;
    background-color: black;
  }
    .footer img{
        width: 150px;
        height: 75px;
        margin: 5px 0px 0px 10px;
    }
    .social{
        width: 500px;
        height: 60px;
        margin: -70px 0px 0px 810px;
        background-color: none;
    }
        .social a img{
            width: 50px;
            height: 50px;
            margin: 5px 0px 0px 30px;
        }
      .footer-content{
    height: 180px;
    width: 1350px;
    background-color: none;
    margin: 0px 0px 0px 0px;
  }
       .footer-content div{
        float: left;
        width: 200px;
        height: 180px;
        background-color: none;
        margin: 0px 0px 0px 80px;

       }
       .footer-content div h2{
        text-align: center;
        align-items: center;
        color: white;
        font-size: 25px;
        border-bottom: 2px solid white;
        font-weight: bold;

       }
           .footer-content div a{
            color: white;
           margin: 0px 0px 0px 55px;
             font-size: 20px;
           }
           .copyright{
            background-color:#1b1c1b;
            width: 500px;
            height: 40px;
            margin: -18px 0px 0px 400px;
           }
           .copyright p{
            color: white;
            text-align: center;
            align-items: center;
            padding-top: 10px;
            font-size: 18px;
            }     
</style>
</head>
<body>
<header>
    
    <section class="section-2">
        <div class="logo"><img src="lucknowlogo.jpg"></div>
        <div class="phone-apointment">
            <div class="phone-number"><i class="fas fa-phone"></i>+917525818779</div>
            <div class="appointment"><button type="button">institute7525@gmail.com</button></div>
        </div>
    </section>

    <nav>

        <div id="toggle-btn">
            <label for="toggle">
                <i class="fas fa-bars"></i>
            </label>   
        </div>

        <input type="checkbox" id="toggle">
        <ul>
            <li><a href="homepage.php"><i class="fas fa-home"></i> HOME</a></li>
            <li><a href="service.php"><i class="fas fa-medkit"></i> SERVICES</a></li>
            <li><a href="admissionform.php"><i class="fas fa-user-md"></i> ADMISSION</a></li>
            <li><a href="contactus.php"><i class="fas fa-address-book"></i> CONTACT US</a></li>
            <li><a href="aboutus.php"><i class="fas fa-question-circle"></i> ABOUT US</a></li>
        </ul>
    </nav>

</header>
<div class="service">
	<img src="service.jpg">
	<h2>Get Ready to Our Services</h2>
	<p>Best Engineering College in Lucknow</p>
	
</div>


<div class="course">
	<div><img src="pc.jpg"><h2>Web Developement</h2><p>You can learn web developement <br>from this website.</p></div>
	<div><img src="pc1.jpg"><h2>Web Design</h2><p>You can learn web design <br>from this website.</p></div>
	<div><img src="pc2.jpg"><h2>Website Developer</h2><p>You can learn website developement <br>from this website.</p></div>
	<div><img src="pc3.jpg"><h2>Graphic Design</h2><p>You can learn Graphic Design <br>from this website.</p></div>
	<div><img src="pc4.jpg"><h2>Php Developement</h2><p>You can learn Php developement <br>from this website.</p></div>
	<div><img src="pc5.jpg"><h2>java Developement</h2><p>You can learn Java developement <br>from this website.</p></div>
	<div><img src="pc6.jpg"><h2>Photography</h2><p>You can learn Photography & Photoshop <br>from this website.</p></div>
	<div><img src="pc7.jpg"><h2>Apps Interface</h2><p>You can learn web developement <br>from this website.</p></div>

</div>


<div class="footer">
    <img src="lucknowlogo.jpg">
    <div class="social">
       <a href="https://www.facebook.com/profile.php?id=100084995330326"><img src="fb.jpg"></a>
        <a href="https://instagram.com/kamlesh79545"><img src="insta.jpg"></a>
         <a href="https://t.me/+kGm0dLyC9TA3YjY1"><img src="telegram.jpg"></a>
          <a href="https://twitter.com/kamlesh16071787?t=zl7rITgpsHR1cgRlMp7NbA&s=09"><img src="twitter.jpg"></a>
           <a href="https://chat.whatsapp.com/JqYgmVqMEPU9BVjqVE8aa4"><img src="whatsapp.jpg"></a>
    </div><br><hr>

<div class="footer-content">
  <div>
      <h2>Company</h2>
      <a href="homepage.php">Home</a><br>
      <a href="contactus.php">Contact us</a><br>
      <a href="aboutus.php">About us</a><br>
      <a href="admissionform.php">Admission</a>

  </div> 
  

  <div>
     <h2>Colleges</h2>
      <a href="https://www.aimt.edu.in">AIMT/AIPS</a><br>
      <a href="https://bbdu.ac.in">BBD</a><br>
      <a href="https://mgimt.edu.in">MGIMT</a><br>
       <a href="https://smslucknow.ac.in">SMS</a>
  </div>
   <div>
     <h2>Colleges</h2>
      <a href="https://srmcem.ac.in">SRM</a><br>
      <a href="https://www.ritm.in">RITM</a><br>
      <a href="http://www.tirupatipolytechnic.org/">Tirupati</a><br>
       <a href="https://www.litlucknow.ac.in">LIT</a>
  </div>
  <div>
      <h2>Services</h2>
      <a href="###">App Design</a><br>
      <a href="###">Web Design</a><br>
      <a href="###">Graphic Design</a><br>
       <a href="###">Developement</a>
  </div>
   </div>
   <div class="copyright">
       <p>Copyright @2022 Lucknow. All right reserved</p>
   </div>
</div>

</body>
</html>