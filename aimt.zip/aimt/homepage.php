<?php
mysql_connect("localhost","root","");
mysql_select_db(aimt);
if(isset($_POST['submit']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $messege=$_POST['messege'];
    $comment_store="insert into comment(Name,Email,Messege)values('$name','$email','$messege')";
    if(mysql_query($comment_store))
    {
        echo " ";
    }
    else
    {
        echo " ";
    }
}


?>
<?php
mysql_connect("localhost","root","");
mysql_select_db(aimt);
if(isset($_POST['admission']))
{
    $name  =$_POST['name'];
    $phone =$_POST['phone'];
    $email =$_POST['email'];
  
    $result="insert into new_admission(name,phone,email)values('$name','$phone','$email')";
    if(mysql_query($result))
    {
        echo " ";
    }
    else
    {
        echo " ";
    }
}


?>



<html>
<head>
<title>Lucknow Institute</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">

<style type="text/css">
    
    *{
    font-family: poppins;
    box-sizing: border-box;
    text-decoration: none;
}

body{
    margin: 0%;
    background:url(bg.jpg)no-repeat; 
    background-size: 1370px auto; 
}

section.section-1,section.section-2{
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    background-color: black;
}
.logo img{
    width: 120px;
    height: 70px;
}

div.block-1{
    display: flex;
    align-items: center;
}

div.block-1 div:first-child{
    margin-right: 40px;
}

div.phone-apointment{
    display: flex;
    align-items: center;
}

div.social-btn ul li i{
    font-size: 22px;
    margin: 10px 7px;
    color: dimgray;
}

div.social-btn ul li i:hover{
    color: steelblue;
}

ul{
    list-style: none;
    padding: 0;
    margin: 0;
    cursor: default;
}

li{
    display: inline-block;
}

div.phone-number{
    font-size: 18px;
    padding: 5px 10px;
    border: 1px solid red;
    border-radius: 20px;
    background-color: white;
}

div.phone-number i{
    transform: rotateY(180deg);
}

div.appointment button{
    border: none;
    background-color: #211163;
    font-size: 18px;
    color: white;
    padding: 10px 12px;
    border-radius: 30px;
    outline: none;
    margin: 0px 15px;
    transition: box-shadow 0.5s;
}

div.appointment button:hover{
    box-shadow: 0px 0px 15px white;
}

nav{
    background-color: #211163;
}

nav ul{
    text-align: center;
}

nav li{
    text-align: center;
}

nav ul li a{
    font-size: 18px;
    display: block;
    color: white;
    padding: 8px 10px;
    margin: 0px 5px;
    font-weight: 500;
    border-top: 4px solid transparent;    
    border-bottom: 4px solid transparent;
    border-radius: 2px;
    transition-property: border-bottom,background-color;
    transition-duration: 0.4s;
}

nav ul li a:hover{
    background-color: black;
    border-bottom: 4px solid white;
}
#toggle{
    display: none;
}

#toggle-btn{
    display: none;
    text-align: right;
}

#toggle-btn i{
    font-size: 25px;
    padding: 7px;
    background-color: white;
    margin: 10px;
    border-radius: 5px;
    cursor: pointer;
}




























@media screen and (min-width: 500px) and (max-width: 768px)
{
    
    body{
        background:url(.jpg)no-repeat;
        background-size: 765px 800px; 
       
    }
section.section-1{
    font-size: 14px;
    flex-direction: column;
}

div.block-1{
    flex-direction: row;
}

div.block-1 div:first-child{
    margin-right: 40px;
}

div.social-btn ul li i{
    font-size: 14px;
}

section.section-2{
    flex-direction: column;
    padding-bottom: 12px;
}

div.phone-number{
    font-size: 12px;
}

div.appointment button{
    font-size: 12px;
}

#toggle-btn{
    display: block;
}

#toggle-btn i{
    font-size: 20px;
    padding: 8px;
}

nav > ul{
    display: none;
}

#toggle:checked + ul{
    display: block;
}

nav ul li{
    display: block;
    text-align: left;
}

nav ul li a{
    font-size: 14px;
}    
 }

@media screen and (max-width: 500px)
{
   body{
      background:url(i2.jpg)no-repeat;
        background-size: 500px 850px; 

    }
section.section-1{
    font-size: 14px;
}

div.block-1{
    flex-direction: column;
}

div.block-1 div:first-child{
    margin-right: 0px;
}

div.social-btn ul li i{
    font-size: 14px;
}

section.section-2{
    flex-direction: column;
    padding-bottom: 12px;
}

div.phone-number{
    font-size: 16px;
}

div.appointment button{
    font-size: 14px;
}

#toggle-btn{
    display: block;
}

nav > ul{
    display: none;
}

#toggle:checked + ul{
    display: block;
}

nav ul li{
    display: block;
    text-align: left;
}


nav ul li a{
    font-size: 16px;
}
}

.content{
            width: 600px;
            height: 450px;
            
            margin-left: 50px;
            margin-top: 150px;
            background-color: none;
        }

        .content h2{
            display: inline-block;
            text-align: center;
            margin-left: 200px;
            color: black;
            margin-top: 0px;
        }
         .content h1{
            text-align: center;
            display: inline-block;
            color: black;
            font-size: 40px;
            margin-top: 0px;
        }

            .content p{
                font-size: 20px;
                display: inline-block;
                text-align: center;
                color: black;
                font-weight: bold;
            }

.new-admission{
    width: 320px;
    height: 350px;
    background-color: rgba(0,0,0,0.5);
   margin:-450px 0px 0px 800px;

}
.new-admission h1{
    font-size: 23px;
    color: white;

}
.new-admission input[type="text"]{
    width: 316px;
    height: 50px;
    border:1px solid black;
    padding: 20px;
    background-color: rgba(0,0,0,0.1);
    font-size: 19px;
    color: white;
}
.new-admission input[type="number"]{
    width: 316px;
    height: 50px;
    border:1px solid black;
    padding: 20px;
     margin: 20px 0px 0px 0px;
     background-color: rgba(0,0,0,0.1);
    font-size: 19px;
    color: white;
}
.new-admission input[type="email"]{
    width: 316px;
    height: 50px;
    border:1px solid black;
    padding: 20px;
     margin: 20px 0px 0px 0px;
     background-color: rgba(0,0,0,0.1);
    font-size: 19px;
    color: white;
}
.new-admission input[type="submit"]{
    width: 120px;
    height: 45px;
    border:1px solid black;
    padding: 20px;
    text-align: center;
    margin: 20px 0px 0px 100px;
    border-radius: 0px 20px;
    background-color: rgba(0,0,0,0.5);
    font-size: 19px;
    color: white;
}
.new-admission input[type="submit"]:hover{
    background-color: white;
    box-shadow: 0px 0px 10px white;
    color: black;
    transition: box-shadow 0.8s;
}
.new-admission input[type="submit"]:active{
    background-color: green;
}
::-webkit-input-placeholder{
    color: white;
    font-size: 21px;
}





            .best{
    width: 1350px;
    height: 350px;
    background:none;
    margin:270px 0px 0px 0px; 

}
.best div{
    width: 350px;
    height: 300px;
    background:#753a15;
    border-radius: 10px;
    margin-left: 70px;
    margin-top: 20px;
    float: left;
box-shadow: 2px 2px 30px 2px black;
}
.best div h1{
    margin-left: 30px;
    color: black;
}
.best div p{
    margin-left:10px;
    margin-top: 30px;
    font-size: 19px; 
    color: black;
}
.best div:hover{
    box-shadow: 2px 2px 50px white;
    background:#55ada5;
    width: 400px;
    height: 350px; 
    margin:0px 5px 5px 35px;
}
.best div p:hover{
    color: white;
        font-size: 23px;

}
            .img{
    margin-top:0px;
    box-shadow: 0px 0px 20px 7px black;
    width: 1350px;

}
.upwrite{
    font-size: 37px;
    margin-left: 500px;
    margin-top: 30px;
    display: inline-block;
    color: black;
}

.hr2{
    width: 1200px;
    height: 1.5px;
    background:#4d4949;
    margin-top: 10px;
    margin-left: 80px;
    }
.upmeeting{
    width: 750px;
    height: 300px;
    background:none;
    margin-top:-660px;
    margin-left: 550px;
}
.upmeeting div{
    float: left;
    margin-left: 80px;
    width: 280px;
    height: 320px;
    background:#a69b9a;
    box-shadow: 2px 2px 30px 5px black;
    border-radius: 20px;
}
.upmeeting div h1{
    font-size: 20px;
    margin-left: 25px;
}
.upmeeting div p{
    margin-top: 20px;
    margin-left: 10px;
}
.upmeeting div img{
    width: 280px;
    height: 160px;
    border-radius: 20px;
}
.upmeeting div:hover{
    box-shadow: 2px 2px 50px red;
}



.upmeeting1{
    width: 750px;
    height: 300px;
    background:none;
    margin-top:60px;
    margin-left: 550px;
}
.upmeeting1 div{
    float: left;
    margin-left: 80px;
    width: 280px;
    height: 320px;
    background:#a69b9a;
    box-shadow: 2px 2px 30px 5px black;
    border-radius: 20px;
}
.upmeeting1 div h1{
    font-size: 20px;
    margin-left: 25px;
}
.upmeeting1 div p{
    margin-top: 20px;
    margin-left: 10px;
}
.upmeeting1 div img{
    width: 280px;
    height: 160px;
    border-radius: 20px;
}
.upmeeting1 div:hover{
    box-shadow: 2px 2px 50px red;
}
.bachelor{
    width: 350px;
    height: 650px;
    background:#55ada5;
    margin-left: 100px;
    margin-top: 60px;
    border-radius: 25px;
    box-shadow: 2px 2px 30px 5px black;
}
.bachelor div h1{
    font-size: 22px;
    margin-top: 0px;
    margin-bottom:0px;
    text-decoration: none;
    color: white;
    display: inline-block;
}
.bachelor div p{
    margin-top: 70px;
    margin-left:15px;
    font-size: 20px; 
    text-decoration: none;
    display: inline-block;
}
.bachelor div div{
    width: 180px;
    height: 40px;
    background:blue;
    margin-top: 60px;
    margin-left: 60px;
    border-radius: 20px;
}

.bachelor div div ul li{
    display: inline-block;
    border-radius: 10px;
    margin-top: 10px;
}
.bachelor div div ul li a{
    text-decoration: none;
    color: white;
    margin-left: 30px;
    margin-top: 10px;
}
.bachelor div div:hover{
    background:green;
    height: 40px;
}
.bachelor div:hover{
    box-shadow: 2px 2px 30px red;
    height: 650px;
    background:#fa1eeb;

}
.coursewrite{
    font-size: 35px;
    margin-top:80px;
    margin-left: 50px; 
}
.hr3{
    width: 1200px;
    height: 2px;
    background:#4d4949;
    margin-top: 10px;
    margin-left: 50px;
}
.course{
    width: 1320px;
    height: 300px;
    background:none;
    margin-top: 40px;
    margin-left: 15px;
}
.course div{
    width: 300px;
    height: 300px;
    background:white;
    float: left;
    margin-left: 25px;
    
    border-radius: 5px;
    box-shadow: 2px 2px 35px grey;
}
.courseimg{

    width: 300px;
    height: 180px;
}
.course div p{
    font-size: 18px;
    margin-top: 10px;
    margin-left: 80px;
}
.course div:hover{
    box-shadow: 2px 2px 30px white;
}
.star{
    width: 120px;
    height: 60px;
    margin-top: -10px;
}
.course div h3{
    font-size: 21px;
    margin-top: -46px;
    margin-left: 210px;
    color: blue;
}
.fact{
    margin-left: 60px;
}
.fewfact{
    width: 700px;
    height: 280px;
    background:none;
    margin-top:40px;
    margin-left: 40px; 
}
.fewfact div{
    float: left;
    margin-left: 70px;
    background:white;
    width: 230px;
    height: 170px;
    margin-top: 30px;
    border-radius: 30px;
    box-shadow:2px 2px 30px red;
    background:white; 
}
.fewfact div h1{
    font-size:50px;
    text-align: center; 
    margin-top: 30px;
}
.fewfact div p{
    font-size:20px;
    text-align: center;
    margin-top: 30px;
}
.fewfact div:hover{
    box-shadow:2px 2px 30px black;
    background:blue;
}
.fewfact1{
    width: 700px;
    height: 280px;
    background:none;
    margin-top:-40px;
    margin-left: 160px; 
}
.fewfact1 div{
    float: left;
    margin-left: 70px;
    background:white;
    width: 230px;
    height: 170px;
    margin-top: 30px;
    border-radius: 30px;
    
    box-shadow:2px 2px 30px red;
    background:white; 
}
.fewfact1 div h1{
    font-size:50px;
    text-align: center; 
    margin-top: 30px;
}
.fewfact1 div p{
    font-size:20px;
    text-align: center;
    margin-top: 30px;
}
.fewfact1 div:hover{
    box-shadow: 2px 2px 20px black;
    background:blue; 
}



.aimt{
    margin-top: -450px;
    margin-left: 900px;
    background-color: none;
    width: 400px;
    height: 280px;
}
.aimt video{
    width: 400px;
    height: 280px;
}
.aimt h1{
    text-align: center;
    align-items: center;
}


.video{
    width: 1300px;
    height: 200px;
    margin-left:0px;
    margin-top: 10px;
    background-color: none;

}
.video h1{
    text-align: center;
    align-items: center;
}
.video h3{
    text-align: center;
    align-items: center;
}
.video li{
    float: left;
    text-decoration: none;
    display: inline-block;
    margin: 0px 0px 0px 20px;
}
.video  video{
    width: 300px;
    height: 190px;
}

.comment-box{
    width:700px;
    height:600px;
    margin: 0px 0px 0px 20px;
}
    .comment-box h1{
        font-size: 45px;
    }
    
    .comment-box input[type="text"]{
        margin: 40px 0px 0px 0px;
        width:600px;
        height: 60px;
        border-radius: 3px solid grey;
        border:none;
            border-bottom: 3px solid black;
            border-top: 2px solid transparent;
            background-color:rgba(0,0,0,0.1);
        color: white;
        font-size: 22px;

    }   
.textarea{
    width: 600px;
    height:130px;
     background-color:rgba(0,0,0,0.1);
     outline: none;
     transition: all 10s;
     margin: 40px 0px 0px 0px;
     font-size: 22px;
     resize: none;

}
.comment-box input[type="submit"]{
        margin: 20px 0px 0px 190px;
        width:160px;
        height: 40px;
        border-radius: 0px 50px;
        border:none;
        box-shadow: 0px 0px 0px 1px black;
        background-color:grey;
        color: white;
        font-size: 22px;
    }   
    .comment-box input[type="submit"]:hover{
         background-color:green;
         box-shadow: 0px 0px 10px white;
         transition: width 10s;
         width: 90px;

    }
    .comment-box input[type="submit"]:active{
        width:160px;
        height: 40px;
        border-radius: 2px solid green;
        border:none;
        box-shadow: 0px 0px 0px 0px black;
            background-color:green;
        color: white;
        font-size: 22px;
    }

  .footer{
    width: 1360px;
    height: 330px;
    background-color: black;
  }
    .footer img{
        width: 150px;
        height: 75px;
        margin: 5px 0px 0px 10px;
    }
    .social{
        width: 500px;
        height: 60px;
        margin: -70px 0px 0px 810px;
        background-color: none;
    }
        .social a img{
            width: 50px;
            height: 50px;
            margin: 5px 0px 0px 30px;
        }
      .footer-content{
    height: 180px;
    width: 1350px;
    background-color: none;
    margin: 0px 0px 0px 0px;
  }
       .footer-content div{
        float: left;
        width: 200px;
        height: 180px;
        background-color: none;
        margin: 0px 0px 0px 80px;

       }
       .footer-content div h2{
        text-align: center;
        align-items: center;
        color: white;
        font-size: 25px;
        border-bottom: 2px solid white;
        font-weight: bold;

       }
           .footer-content div a{
            color: white;
           margin: 0px 0px 0px 55px;
             font-size: 20px;
           }
           .copyright{
            background-color:#1b1c1b;
            width: 500px;
            height: 40px;
            margin: -15px 0px 0px 400px;
           }
           .copyright p{
            color: white;
            text-align: center;
            align-items: center;
            padding-top: 10px;
            font-size: 18px;
            }           
            








</style>

</head>
<body>

<header>
    
    <section class="section-2">
        <div class="logo"><img src="lucknowlogo.jpg"></div>
        <div class="phone-apointment">
            <div class="phone-number"><i class="fas fa-phone"></i>+917525818779</div>
            <div class="appointment"><button type="button">institute7525@gmail.com</button></div>
        </div>
    </section>

    <nav>

        <div id="toggle-btn">
            <label for="toggle">
                <i class="fas fa-bars"></i>
            </label>   
        </div>

        <input type="checkbox" id="toggle">
        <ul>
            <li><a href="homepage.php"><i class="fas fa-home"></i> HOME</a></li>
            <li><a href="service.php"><i class="fas fa-medkit"></i> SERVICES</a></li>
            <li><a href="admissionform.php"><i class="fas fa-user-md"></i> ADMISSION</a></li>
            <li><a href="contactus.php"><i class="fas fa-address-book"></i> CONTACT US</a></li>
            <li><a href="aboutus.php"><i class="fas fa-question-circle"></i> ABOUT US</a></li>
        </ul>
    </nav>

</header>






<div class="all-page">
 <div class="bgup">   
<div class="content">
   
    <h2>Hello Student !</h2><br><br>
    <h1>WELCOME TO EDUCATION IN LUCKNOW </h1><br><br>
    <p>The top engineering colleges in Lucknow include 62 names like BBD Lucknow, AIMT Lucknow, and many other colleges. These colleges are ranked by agencies like NIRF and offer various courses like BTech, MTech, Diploma and BCA in Engineering.</p>
  
</div>
<div class="new-admission">
    <form method="post" autocomplete="off">
        <table>
            <marquee behavior="alternate"><h1>New Admission</h1></marquee>
            <tr>
                <td><input type="text" name="name" placeholder="Your Name"></td>
            </tr>
            <tr>
                <td><input type="number" name="phone" placeholder="Phone Number"></td>
            </tr>
            <tr>
                <td><input type="email" name="email" placeholder="Email Id"></td>
            </tr>
            <tr>
                <td><input type="submit" name="admission"></td>
            </tr>
        </table>
    </form>
</div>

<div class="best">
    <div data-aos="slide-up"> <h1  data-aos="slide-up">BEST EDUCATION</h1><p data-aos="slide-up">College is important for many reasons, including long-term financial gain, job stability, career satisfaction and success outside of the workplace. With more and more occupations requiring advanced education, a college degree can be critical to your success in today's workforce.</p></div>
    <div data-aos="slide-up"> <h1 data-aos="slide-up">BEST TEACHERS</h1><p  data-aos="slide-up">What can I write about my best teacher?
She is a very sweet and kind person. She explains everything in an easy and fun way. Whenever we are not able to understand anything, she patiently teaches it again and again. She is very disciplined, punctual and sometimes strict too.</p></div>
    <div data-aos="slide-up"><h1  data-aos="slide-up">BEST STUDENTS</h1><p  data-aos="slide-up">Why Being a college student is important?
College is important for many reasons, including long-term financial gain, job stability, career satisfaction and success outside of the workplace. With more and more occupations requiring advanced education, a college degree can be critical to your success in today's workforce.</p></div>
</div>
<h1 class="upwrite">UPCOMING MEETING</h1>
<div class="hr2"></div>


<div class="bachelor" data-aos="slide-up">
    <div data-aos="slide-up">
    <h1>APPLY FOR B.TECH & M.TECH</h1>
    <p>B.Tech in computer science and engineering is very good at this university. As there is a good scope in CSE, many students pursue it. In our batch, there is a total of a hundred students. Students can get a job in cybersecurity, networking, data scientist, software programmer, etc.<br><br>M.Tech with good salary packages include Project Manager, Senior Engineer, Research Associate, Development Engineer, Construction Manager, Machinery Engineer, Maintenance Manager, Software Developer, Researcher, etc. Apart from this, students can also go for a career in the teaching profession after completing their M.Tech</p>
    <div><ul>
        <li><a href="###">JOIN US NOW</a></li>
    </ul></div>
</div>
</div>

<div class="upmeeting">
    <div data-aos="slide-up"><img src="img2.jpg"><h1>LECTURERS MEETING</h1><p>The classroom lecture is a special form of communication in which voice, gesture, movement, facial expression, and eye contact can either complement or detract from the content.</p></div>
    <div data-aos="slide-up"><img src="img3.jpg"><h1>ONLINE TEACHING</h1><p>Online education offers extensive benefits to students by giving a manageable schedule, student enhancement and augmented education access and choice. </p></div>
</div>


<div class="upmeeting1">
    <div data-aos="slide-up"><img src="img6.jpg"><h1>STUDENTS LIBRARY</h1><p>  A place in which literary, musical, artistic, or reference materials (such as books, manuscripts, recordings, or films) are kept for use but not for sale.</p></div>
    <div data-aos="slide-up"><img src="img4.jpg"><h1>HIGHER EDUCATION</h1><p>After going to college, you may have improved career opportunities, receive higher pay, experience greater cultural awareness, and have a life with more choices and possibilities</p></div>
</div>
<h1 class="coursewrite">OUR POPULAR COURSES</h1>
<div class="hr3"></div>

<div class="course">
    <div data-aos="slide-up"><img src="img7.jpg" class="courseimg"><p>Please visit our <br>website again.</p><img src="star.jpg" class="star"><h3>$10</h3></div>
    <div data-aos="slide-up"><img src="img8.jpg" class="courseimg"><p>Responsive HTML<br> template for you.</p><img src="star.jpg" class="star"><h3>$14</h3></div>
    <div data-aos="slide-up"><img src="img1.jpg" class="courseimg"><p>Download free CSS<br>layouts for your business.</p><img src="star.jpg" class="star"><h3>$20</h3></div>
    <div data-aos="slide-up"><img src="img5.jpg" class="courseimg"><p>My college is best college <br>in Lucknow for placement.</p><img src="star.jpg" class="star"><h3>$25</h3></div>
</div><br><br><br>


<h1 class="fact">A Few Facts About Lucknow Engineering College</h1>
<div class="hr3"></div>

<div class="fewfact">
    <div data-aos="flip-right"><h1>96%</h1><p>Succesed Students</p></div>
    <div  data-aos="flip-left"><h1>2250</h1><p>New Students</p></div>
</div>
<div class="fewfact1">
    <div  data-aos="flip-left"><h1>127</h1><p>Current Teachers</p></div>
    <div  data-aos="flip-right"><h1>37</h1><p>Awards</p></div>
</div>


<div class="aimt" data-aos="slide-up">
<video width="400px" controls >
    <source src="aips.mp4">
</video>
<h3>Ambalika Institute Of Management & Technology</h3>
<h1>(AIMT/AIPS)</h1>
</div>
<br><br><br><br><br><br><br><br>


<div class="video" data-aos="slide-up">
    
<li>
<video width="400px" controls>
    <source src="srm.mp4">
</video>
<h3>Shri Ramswaroop College Of</h3>
<h3> Engineering & Management</h3>
<h1>(SRM)</h1>
</li>

<li>
<video width="400px" controls >
    <source src="ritm.mp4">
</video>
<h3>Rameshwaram Institute Of</h3>
<h3>Technology & Management</h3>
<h1>(RITM)</h1>
</li>

<li>
<video width="400px" controls >
    <source src="integral.mp4">
</video>
<h3>Integral University</h3>
<h1>(INTEGRAL)</h1>
</li>

<li>
<video width="400px" controls >
    <source src="bbd.mp4">
</video>
<h3>Babu Banarasi Das University</h3>
<h1>(BBD)</h1>
</li>

</div>
<br><br><br><br><br><br><br><br><br><hr><hr>

<div class="comment-box" data-aos="slide-up">
<h1>Leave A Comment</h1>

    <form method="post">
        <input type="text" name="name" placeholder="Enter Your Name">
        <input type="text" name="email" placeholder="Enter Your Email"><br>
        <textarea class="textarea" placeholder="Write Query....." name="messege"></textarea>
        <input type="submit" name="submit" value="Send Messege">
    </form>

</div>




<div class="footer">
    <img src="lucknowlogo.jpg">
    <div class="social">
       <a href="https://www.facebook.com/profile.php?id=100084995330326"><img src="fb.jpg"></a>
        <a href="https://instagram.com/kamlesh79545"><img src="insta.jpg"></a>
         <a href="https://t.me/+kGm0dLyC9TA3YjY1"><img src="telegram.jpg"></a>
          <a href="https://twitter.com/kamlesh16071787?t=zl7rITgpsHR1cgRlMp7NbA&s=09"><img src="twitter.jpg"></a>
           <a href="https://chat.whatsapp.com/JqYgmVqMEPU9BVjqVE8aa4"><img src="whatsapp.jpg"></a>
    </div><br><hr>

<div class="footer-content">
  <div>
      <h2>Company</h2>
      <a href="homepage.php">Home</a><br>
      <a href="contactus.php">Contact us</a><br>
      <a href="aboutus.php">About us</a><br>
      <a href="admissionform.php">Admission</a>

  </div> 
  

  <div>
     <h2>Colleges</h2>
      <a href="https://www.aimt.edu.in">AIMT/AIPS</a><br>
      <a href="https://bbdu.ac.in">BBD</a><br>
      <a href="https://mgimt.edu.in">MGIMT</a><br>
       <a href="https://smslucknow.ac.in">SMS</a>
  </div>
   <div>
     <h2>Colleges</h2>
      <a href="https://srmcem.ac.in">SRM</a><br>
      <a href="https://www.ritm.in">RITM</a><br>
      <a href="http://www.tirupatipolytechnic.org/">Tirupati</a><br>
       <a href="https://www.litlucknow.ac.in">LIT</a>
  </div>
  <div>
      <h2>Services</h2>
      <a href="###">App Design</a><br>
      <a href="###">Web Design</a><br>
      <a href="###">Graphic Design</a><br>
       <a href="###">Developement</a>
  </div>
   </div>
   <div class="copyright">
       <p>Copyright @2022 Lucknow. All right reserved</p>
   </div>
</div>
 









 <!-- our aos animation data -->

 <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init({
          offset: 200,
            duration: 800, 

        });
  </script>

</body>
</div>
</html>